package com.desarrolloapp.finanzas.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.desarrolloapp.finanzas.R;

public class UserMenuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_menu);

        findViewById(R.id.btnEditProfile).setOnClickListener(v -> startActivity(new Intent(this, EditProfileActivity.class)));
        findViewById(R.id.btnIngresos).setOnClickListener(v -> startActivity(new Intent(this, IngresosActivity.class)));
        findViewById(R.id.btnGastos).setOnClickListener(v -> startActivity(new Intent(this, GastoActivity.class)));

    }
}
