package com.desarrolloapp.finanzas.database.entities;

public class Ingreso {
}
