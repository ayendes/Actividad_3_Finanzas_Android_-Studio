package com.desarrolloapp.finanzas.activities;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.desarrolloapp.finanzas.R;

public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView tvInfo = findViewById(R.id.tvInfo);
        tvInfo.setText("Desarrollador: Abraham Yendes\nVersión: 1.0\nWeb: www.finanzas.com");

    }
}
