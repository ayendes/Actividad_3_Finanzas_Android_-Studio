package com.desarrolloapp.finanzas.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.desarrolloapp.finanzas.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.List;

public class IngresosActivity extends AppCompatActivity {

    private EditText etNombreIngreso, etValorIngreso, etDescripcionIngreso;
    private Spinner spFuenteIngreso;
    private Button btnGuardarIngreso, btnCancelarIngreso, btnEditarIngreso, btnEliminarIngreso;
    private RecyclerView rvIngresos;
    private List<Ingreso> listaIngresos = new ArrayList<>();
    private IngresoAdapter ingresoAdapter;
    private DatabaseReference dbRef;
    private String userId;
    private Ingreso ingresoSeleccionado = null;
    private int spinnerSelectedIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresos);

        etNombreIngreso = findViewById(R.id.etNombreIngreso);
        etValorIngreso = findViewById(R.id.etValorIngreso);
        etDescripcionIngreso = findViewById(R.id.etDescripcionIngreso);
        spFuenteIngreso = findViewById(R.id.spFuenteIngreso);
        btnGuardarIngreso = findViewById(R.id.btnGuardarIngreso);
        btnEditarIngreso = findViewById(R.id.btnEditarIngreso);
        btnEliminarIngreso = findViewById(R.id.btnEliminarIngreso);
        btnCancelarIngreso = findViewById(R.id.btnCancelarIngreso);
        rvIngresos = findViewById(R.id.rvIngresos);

        btnEliminarIngreso.setEnabled(false);

        // Colocacion de arrays.xml por defecto en spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.fuentes_ingreso,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFuenteIngreso.setAdapter(adapter);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            userId = currentUser.getUid();
            dbRef = FirebaseDatabase.getInstance().getReference("ingresos").child(userId);
        } else {
            Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Configurar lista de Ingresos guardados
        ingresoAdapter = new IngresoAdapter(listaIngresos, ingreso -> {
            ingresoSeleccionado = ingreso;
            etNombreIngreso.setText(ingreso.nombre);
            etValorIngreso.setText(ingreso.valor);
            etDescripcionIngreso.setText(ingreso.descripcion);
            for (int i = 0; i < spFuenteIngreso.getCount(); i++) {
                if (spFuenteIngreso.getItemAtPosition(i).toString().equals(ingreso.fuente)) {
                    spFuenteIngreso.setSelection(i);
                    break;
                }
            }
            btnEditarIngreso.setEnabled(true);
            btnEliminarIngreso.setEnabled(true);
        });


        rvIngresos.setLayoutManager(new LinearLayoutManager(this));
        rvIngresos.setAdapter(ingresoAdapter);

        cargarIngresos();

        btnGuardarIngreso.setOnClickListener(v -> {
            String nombre = etNombreIngreso.getText().toString().trim();
            String valor = etValorIngreso.getText().toString().trim();
            String fuente = spFuenteIngreso.getSelectedItem().toString();
            String descripcion = etDescripcionIngreso.getText().toString().trim();

            if (TextUtils.isEmpty(nombre)) {
                etNombreIngreso.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(valor)) {
                etValorIngreso.setError("Campo requerido");
                return;
            }

            String id = dbRef.push().getKey();
            Ingreso ingreso = new Ingreso(id, nombre, valor, fuente, descripcion);

            dbRef.child(id).setValue(ingreso)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Ingreso guardado", Toast.LENGTH_SHORT).show();
                        limpiarCampos();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show());
        });

        btnEditarIngreso.setOnClickListener(v -> {
            if (ingresoSeleccionado == null) {
                Toast.makeText(this, "Seleccione un ingreso para editar", Toast.LENGTH_SHORT).show();
                return;
            }
            String nombre = etNombreIngreso.getText().toString().trim();
            String valor = etValorIngreso.getText().toString().trim();
            String fuente = spFuenteIngreso.getSelectedItem().toString();
            String descripcion = etDescripcionIngreso.getText().toString().trim();

            if (TextUtils.isEmpty(nombre)) {
                etNombreIngreso.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(valor)) {
                etValorIngreso.setError("Campo requerido");
                return;
            }

            ingresoSeleccionado.nombre = nombre;
            ingresoSeleccionado.valor = valor;
            ingresoSeleccionado.fuente = fuente;
            ingresoSeleccionado.descripcion = descripcion;

            dbRef.child(ingresoSeleccionado.id).setValue(ingresoSeleccionado)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Ingreso actualizado", Toast.LENGTH_SHORT).show();
                        limpiarCampos();
                        ingresoSeleccionado = null;
                        btnEditarIngreso.setEnabled(false);
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show());
        });

        btnEliminarIngreso.setOnClickListener(v -> {
            if (ingresoSeleccionado == null) {
                Toast.makeText(this, "Seleccione un ingreso para eliminar", Toast.LENGTH_SHORT).show();
                return;
            }
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Eliminar ingreso")
                    .setMessage("¿Seguro que desea eliminar este ingreso?")
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        dbRef.child(ingresoSeleccionado.id).removeValue()
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(this, "Ingreso eliminado", Toast.LENGTH_SHORT).show();
                                    limpiarCampos();
                                    ingresoSeleccionado = null;
                                    btnEditarIngreso.setEnabled(false);
                                    btnEliminarIngreso.setEnabled(false);
                                })
                                .addOnFailureListener(e -> Toast.makeText(this, "Error al eliminar", Toast.LENGTH_SHORT).show());
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });

        btnCancelarIngreso.setOnClickListener(v -> finish());
        btnEditarIngreso.setEnabled(false);
        btnEliminarIngreso.setEnabled(false);

    }

    private void limpiarCampos() {
        etNombreIngreso.setText("");
        etValorIngreso.setText("");
        etDescripcionIngreso.setText("");
        spFuenteIngreso.setSelection(0);
    }

    private void cargarIngresos() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaIngresos.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Ingreso ingreso = ds.getValue(Ingreso.class);
                    listaIngresos.add(ingreso);
                }
                ingresoAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(IngresosActivity.this, "Error al cargar ingresos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Modelo de Ingreso
    public static class Ingreso {
        public String id;
        public String nombre;
        public String valor;
        public String fuente;
        public String descripcion;

        public Ingreso() {} // Constructor vacío

        public Ingreso(String id, String nombre, String valor, String fuente, String descripcion) {
            this.id = id;
            this.nombre = nombre;
            this.valor = valor;
            this.fuente = fuente;
            this.descripcion = descripcion;
        }
    }

    public static class IngresoAdapter extends RecyclerView.Adapter<IngresoAdapter.ViewHolder> {
        private final List<Ingreso> data;
        private final OnIngresoClickListener listener;

        public interface OnIngresoClickListener {
            void onIngresoClick(Ingreso ingreso);
        }

        public IngresoAdapter(List<Ingreso> data, OnIngresoClickListener listener) {
            this.data = data;
            this.listener = listener;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Ingreso ingreso = data.get(position);
            holder.text1.setText(ingreso.nombre + " - $" + ingreso.valor);
            holder.text2.setText("Fuente: " + ingreso.fuente + " | " + ingreso.descripcion);

            holder.itemView.setOnClickListener(v -> {
                if (listener != null) listener.onIngresoClick(ingreso);
            });
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView text1, text2;
            ViewHolder(android.view.View itemView) {
                super(itemView);
                text1 = itemView.findViewById(android.R.id.text1);
                text2 = itemView.findViewById(android.R.id.text2);
            }
        }
    }
}