package com.desarrolloapp.finanzas.database;

public class AppDatabase {
}
