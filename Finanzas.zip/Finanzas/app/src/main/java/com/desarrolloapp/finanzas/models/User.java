package com.desarrolloapp.finanzas.models;

public class User {
    public String identificacion;
    public String tipoIdentificacion;
    public String password;
    public String nombre;
    public String apellido;
    public String genero;
    public String email;
    public String telefono;
    public String rol;
    public String pais;
    public String ciudad;
    public User() {

    }
    public User(String identificacion, String tipoIdentificacion, String password, String nombre, String apellido, String genero, String email, String telefono, String rol, String pais, String ciudad) {
        this.identificacion = identificacion;
        this.tipoIdentificacion = tipoIdentificacion;
        this.password = password;
        this.nombre = nombre;
        this.apellido = apellido;
        this.genero = genero;
        this.telefono = telefono;
        this.rol = rol;
        this.pais = pais;
        this.ciudad = ciudad;

    }
}
