package com.desarrolloapp.finanzas.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.desarrolloapp.finanzas.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

public class EditProfileActivity extends AppCompatActivity {

    private EditText etTelefono, etPassword, etPais, etCiudad;
    private Button btnGuardar, btnEliminar;

    private FirebaseAuth mAuth;
    private DatabaseReference dbRef;
    private String identificacionActual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        etTelefono = findViewById(R.id.etTelefono);
        etPassword = findViewById(R.id.etPassword);
        etPais = findViewById(R.id.etPais);
        etCiudad = findViewById(R.id.etCiudad);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnEliminar = findViewById(R.id.btnEliminar);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        dbRef = FirebaseDatabase.getInstance().getReference("usuarios");

        if (currentUser != null) {

            dbRef.orderByChild("email").equalTo(currentUser.getEmail())
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                for (DataSnapshot userSnap : snapshot.getChildren()) {
                                    identificacionActual = userSnap.getKey();
                                    String telefono = userSnap.child("telefono").getValue(String.class);
                                    String pais = userSnap.child("pais").getValue(String.class);
                                    String ciudad = userSnap.child("ciudad").getValue(String.class);

                                    etTelefono.setText(telefono != null ? telefono : "");
                                    etPais.setText(pais != null ? pais : "");
                                    etCiudad.setText(ciudad != null ? ciudad : "");
                                }
                            }
                        }
                        @Override
                        public void onCancelled(DatabaseError error) {}
                    });
        }

        btnGuardar.setOnClickListener(v -> {
            String telefono = etTelefono.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String pais = etPais.getText().toString().trim();
            String ciudad = etCiudad.getText().toString().trim();

            if (TextUtils.isEmpty(telefono)) {
                etTelefono.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(pais)) {
                etPais.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(ciudad)) {
                etCiudad.setError("Campo requerido");
                return;
            }

            // Actualizar password en Base de Datos
            if (!TextUtils.isEmpty(password) && currentUser != null) {
                currentUser.updatePassword(password)
                        .addOnFailureListener(e -> Toast.makeText(this, "Error al actualizar contraseña", Toast.LENGTH_SHORT).show());
            }

            // Actualizar Datos en Base de Datos
            if (identificacionActual != null) {
                dbRef.child(identificacionActual).child("telefono").setValue(telefono);
                dbRef.child(identificacionActual).child("pais").setValue(pais);
                dbRef.child(identificacionActual).child("ciudad").setValue(ciudad);
                Toast.makeText(this, "Datos actualizados", Toast.LENGTH_SHORT).show();
            }
        });
        // Eliminar Datos en Base de Datos
        btnEliminar.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Eliminar cuenta")
                    .setMessage("¿Estás seguro de que deseas eliminar tu cuenta?")
                    .setPositiveButton("Sí, eliminar", (dialog, which) -> {

                        if (currentUser != null && identificacionActual != null) {
                            dbRef.child(identificacionActual).removeValue();
                            currentUser.delete()
                                    .addOnCompleteListener(task -> {
                                        Toast.makeText(this, "Cuenta eliminada", Toast.LENGTH_SHORT).show();
                                        finish();
                                    });
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
    }
}
