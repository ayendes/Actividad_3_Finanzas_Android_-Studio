package com.desarrolloapp.finanzas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.desarrolloapp.finanzas.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

public class LoginActivity extends AppCompatActivity {
    private EditText etIdentificacion, etPassword;
    private Button btnLogin, btnCancel;
    private FirebaseAuth mAuth;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etIdentificacion = findViewById(R.id.etIdentificacion);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCancel = findViewById(R.id.btnCancel);

        mAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference("usuarios");

        btnLogin.setOnClickListener(v -> {
            String identificacion = etIdentificacion.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            if (identificacion.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Ingrese identificación y contraseña", Toast.LENGTH_SHORT).show();
                return;
            }

            // Optener email de identificacion para autenticar inicio de sesion
            dbRef.child(identificacion).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String email = snapshot.child("email").getValue(String.class);
                        if (email != null && !email.isEmpty()) {
                            mAuth.signInWithEmailAndPassword(email, pass)
                                    .addOnCompleteListener(LoginActivity.this, task -> {
                                        if (task.isSuccessful()) {
                                            FirebaseUser user = mAuth.getCurrentUser();
                                            startActivity(new Intent(LoginActivity.this, UserMenuActivity.class));
                                            finish();
                                        } else {
                                            Toast.makeText(LoginActivity.this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } else {
                            Toast.makeText(LoginActivity.this, "No se encontró el email asociado.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(LoginActivity.this, "Identificación no registrada.", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    Toast.makeText(LoginActivity.this, "Error de base de datos.", Toast.LENGTH_SHORT).show();
                }
            });
        });

        //Link para recuperacion de password
        findViewById(R.id.tvForgot).setOnClickListener(v -> startActivity(new Intent(this, ForgotPasswordActivity.class)));

        btnCancel.setOnClickListener(v -> finish());
    }
}