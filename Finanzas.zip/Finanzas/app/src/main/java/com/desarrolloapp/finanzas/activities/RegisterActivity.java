package com.desarrolloapp.finanzas.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.desarrolloapp.finanzas.R;
import com.desarrolloapp.finanzas.models.User;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    private Spinner spTipoIdentificacion, spGenero, spRol;
    private EditText etIdentificacion, etPassword, etNombre, etApellido, etEmail, etTelefono, etPais, etCiudad;
    private Button btnGuardar, btnCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        spTipoIdentificacion = findViewById(R.id.spTipoIdentificacion);
        spGenero = findViewById(R.id.spGenero);
        spRol = findViewById(R.id.spRol);
        etIdentificacion = findViewById(R.id.etIdentificacion);
        etPassword = findViewById(R.id.etPassword);
        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etEmail = findViewById(R.id.etEmail);
        etTelefono = findViewById(R.id.etTelefono);
        etPais = findViewById(R.id.etPais);
        etCiudad = findViewById(R.id.etCiudad);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnCancelar = findViewById(R.id.btnCancelar);

        btnGuardar = findViewById(R.id.btnGuardar);
        btnCancelar = findViewById(R.id.btnCancelar);

        // Configuracion de spinner con arrays.xml
        ArrayAdapter<CharSequence> adapterTipoId = ArrayAdapter.createFromResource(this,
                R.array.tipos_identificacion, android.R.layout.simple_spinner_item);
        adapterTipoId.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spTipoIdentificacion.setAdapter(adapterTipoId);

        ArrayAdapter<CharSequence> adapterGenero = ArrayAdapter.createFromResource(this,
                R.array.generos, android.R.layout.simple_spinner_item);
        adapterGenero.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spGenero.setAdapter(adapterGenero);

        ArrayAdapter<CharSequence> adapterRol = ArrayAdapter.createFromResource(this,
                R.array.roles, android.R.layout.simple_spinner_item);
        adapterRol.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spRol.setAdapter(adapterRol);

        btnGuardar.setOnClickListener(v -> {

            String identificacion = etIdentificacion.getText().toString().trim();
            String tipoIdentificacion = spTipoIdentificacion.getSelectedItem().toString();
            String password = etPassword.getText().toString().trim();
            String nombre = etNombre.getText().toString().trim();
            String apellido = etApellido.getText().toString().trim();
            String genero = spGenero.getSelectedItem().toString();
            String email = etEmail.getText().toString().trim();
            String telefono = etTelefono.getText().toString().trim();
            String rol = spRol.getSelectedItem().toString();
            String pais = etPais.getText().toString().trim();
            String ciudad = etCiudad.getText().toString().trim();

            if (TextUtils.isEmpty(identificacion)) {
                etIdentificacion.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(password)) {
                etPassword.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(nombre)) {
                etNombre.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(apellido)) {
                etApellido.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.setError("Email inválido");
                return;
            }
            if (TextUtils.isEmpty(telefono)) {
                etTelefono.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(pais)) {
                etPais.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(ciudad)) {
                etCiudad.setError("Campo requerido");
                return;
            }

            User user = new User();
            user.identificacion = identificacion;
            user.tipoIdentificacion = tipoIdentificacion;
            user.password = password;
            user.nombre = nombre;
            user.apellido = apellido;
            user.genero = genero;
            user.email = email;
            user.telefono = telefono;
            user.rol = rol;
            user.pais = pais;
            user.ciudad = ciudad;


            // Guardar en Base de Datos Firebase Realtime Database
            DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("usuarios");
            dbRef.child(identificacion).setValue(user)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Registro Exitoso", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error al registrar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });

        btnCancelar.setOnClickListener(v -> finish());
    }
}
