package com.desarrolloapp.finanzas.models;

public class Gasto {
    private String id;
    private String nombre;
    private double valor;
    private String categoria;
    private String descripcion;

    public Gasto() {}

    public Gasto(String id, String nombre, double valor, String categoria, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.valor = valor;
        this.categoria = categoria;
        this.descripcion = descripcion;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
