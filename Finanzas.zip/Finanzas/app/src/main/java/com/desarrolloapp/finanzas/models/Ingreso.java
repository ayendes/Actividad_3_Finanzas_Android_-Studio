package com.desarrolloapp.finanzas.models;

public class Ingreso {
    private String id;
    private String nombre;
    private double valor;
    private String fuente;
    private String descripcion;

    public Ingreso() {}

    public Ingreso(String id, String nombre, double valor, String fuente, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.valor = valor;
        this.fuente = fuente;
        this.descripcion = descripcion;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    public String getFuente() { return fuente; }
    public void setFuente(String fuente) { this.fuente = fuente; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}