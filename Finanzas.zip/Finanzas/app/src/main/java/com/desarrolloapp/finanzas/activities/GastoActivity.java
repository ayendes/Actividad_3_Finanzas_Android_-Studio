package com.desarrolloapp.finanzas.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.desarrolloapp.finanzas.R;
import com.desarrolloapp.finanzas.models.Gasto;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.List;

public class GastoActivity extends AppCompatActivity {
    private EditText etNombreGasto, etValorGasto, etDescripcionGasto;
    private Spinner spCategoriaGasto;
    private Button btnGuardarGasto, btnCancelarGasto, btnEditarGasto, btnEliminarGasto;
    private RecyclerView rvGastos;
    private List<Gasto> listaGastos = new ArrayList<>();
    private GastoAdapter gastoAdapter;
    private DatabaseReference dbRef;
    private String userId;
    private Gasto gastoSeleccionado = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gasto);

        etNombreGasto = findViewById(R.id.etNombreGasto);
        etValorGasto = findViewById(R.id.etValorGasto);
        etDescripcionGasto = findViewById(R.id.etDescripcionGasto);
        spCategoriaGasto = findViewById(R.id.spCategoriaGasto);
        btnGuardarGasto = findViewById(R.id.btnGuardarGasto);
        btnCancelarGasto = findViewById(R.id.btnCancelarGasto);
        btnEditarGasto = findViewById(R.id.btnEditarGasto);
        btnEliminarGasto = findViewById(R.id.btnEliminarGasto);
        rvGastos = findViewById(R.id.rvGastos);

        // Completar los spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.categorias_gasto,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategoriaGasto.setAdapter(adapter);


        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            userId = currentUser.getUid();
            dbRef = FirebaseDatabase.getInstance().getReference("gastos").child(userId);
        } else {
            Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Configuracion de la lista de gastos guardados
        gastoAdapter = new GastoAdapter(listaGastos, gasto -> {
            gastoSeleccionado = gasto;
            etNombreGasto.setText(gasto.getNombre());
            etValorGasto.setText(String.valueOf(gasto.getValor()));
            etDescripcionGasto.setText(gasto.getDescripcion());
            for (int i = 0; i < spCategoriaGasto.getCount(); i++) {
                if (spCategoriaGasto.getItemAtPosition(i).toString().equals(gasto.getCategoria())) {
                    spCategoriaGasto.setSelection(i);
                    break;
                }
            }
            btnEditarGasto.setEnabled(true);
            btnEliminarGasto.setEnabled(true);
        });
        rvGastos.setLayoutManager(new LinearLayoutManager(this));
        rvGastos.setAdapter(gastoAdapter);

        cargarGastos();

        btnGuardarGasto.setOnClickListener(v -> {
            String nombre = etNombreGasto.getText().toString().trim();
            String valorStr = etValorGasto.getText().toString().trim();
            String categoria = spCategoriaGasto.getSelectedItem().toString();
            String descripcion = etDescripcionGasto.getText().toString().trim();

            if (TextUtils.isEmpty(nombre)) {
                etNombreGasto.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(valorStr)) {
                etValorGasto.setError("Campo requerido");
                return;
            }

            double valor;
            try {
                valor = Double.parseDouble(valorStr);
            } catch (NumberFormatException e) {
                etValorGasto.setError("Valor inválido");
                return;
            }

            String id = dbRef.push().getKey();
            Gasto gasto = new Gasto(id, nombre, valor, categoria, descripcion);

            dbRef.child(id).setValue(gasto)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Gasto guardado", Toast.LENGTH_SHORT).show();
                        limpiarCampos();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show());
        });

        btnEditarGasto.setOnClickListener(v -> {
            if (gastoSeleccionado == null) {
                Toast.makeText(this, "Seleccione un gasto para editar", Toast.LENGTH_SHORT).show();
                return;
            }
            String nombre = etNombreGasto.getText().toString().trim();
            String valorStr = etValorGasto.getText().toString().trim();
            String categoria = spCategoriaGasto.getSelectedItem().toString();
            String descripcion = etDescripcionGasto.getText().toString().trim();

            if (TextUtils.isEmpty(nombre)) {
                etNombreGasto.setError("Campo requerido");
                return;
            }
            if (TextUtils.isEmpty(valorStr)) {
                etValorGasto.setError("Campo requerido");
                return;
            }

            double valor;
            try {
                valor = Double.parseDouble(valorStr);
            } catch (NumberFormatException e) {
                etValorGasto.setError("Valor inválido");
                return;
            }

            gastoSeleccionado.setNombre(nombre);
            gastoSeleccionado.setValor(valor);
            gastoSeleccionado.setCategoria(categoria);
            gastoSeleccionado.setDescripcion(descripcion);

            dbRef.child(gastoSeleccionado.getId()).setValue(gastoSeleccionado)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Gasto actualizado", Toast.LENGTH_SHORT).show();
                        limpiarCampos();
                        gastoSeleccionado = null;
                        btnEditarGasto.setEnabled(false);
                        btnEliminarGasto.setEnabled(false);
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show());
        });

        btnEliminarGasto.setOnClickListener(v -> {
            if (gastoSeleccionado == null) {
                Toast.makeText(this, "Seleccione un gasto para eliminar", Toast.LENGTH_SHORT).show();
                return;
            }
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Eliminar gasto")
                    .setMessage("¿Seguro que desea eliminar este gasto?")
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        dbRef.child(gastoSeleccionado.getId()).removeValue()
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(this, "Gasto eliminado", Toast.LENGTH_SHORT).show();
                                    limpiarCampos();
                                    gastoSeleccionado = null;
                                    btnEditarGasto.setEnabled(false);
                                    btnEliminarGasto.setEnabled(false);
                                })
                                .addOnFailureListener(e -> Toast.makeText(this, "Error al eliminar", Toast.LENGTH_SHORT).show());
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });

        btnCancelarGasto.setOnClickListener(v -> finish());
        btnEditarGasto.setEnabled(false);
        btnEliminarGasto.setEnabled(false);
    }

    private void limpiarCampos() {
        etNombreGasto.setText("");
        etValorGasto.setText("");
        etDescripcionGasto.setText("");
        spCategoriaGasto.setSelection(0);
    }

    private void cargarGastos() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaGastos.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Gasto gasto = ds.getValue(Gasto.class);
                    listaGastos.add(gasto);
                }
                gastoAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(GastoActivity.this, "Error al cargar gastos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public static class GastoAdapter extends RecyclerView.Adapter<GastoAdapter.ViewHolder> {
        private final List<Gasto> data;
        private final OnGastoClickListener listener;

        public interface OnGastoClickListener {
            void onGastoClick(Gasto gasto);
        }

        public GastoAdapter(List<Gasto> data, OnGastoClickListener listener) {
            this.data = data;
            this.listener = listener;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Gasto gasto = data.get(position);
            holder.text1.setText(gasto.getNombre() + " - $" + gasto.getValor());
            holder.text2.setText("Categoría: " + gasto.getCategoria() + " | " + gasto.getDescripcion());

            holder.itemView.setOnClickListener(v -> {
                if (listener != null) listener.onGastoClick(gasto);
            });
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView text1, text2;
            ViewHolder(android.view.View itemView) {
                super(itemView);
                text1 = itemView.findViewById(android.R.id.text1);
                text2 = itemView.findViewById(android.R.id.text2);
            }
        }
    }
}
