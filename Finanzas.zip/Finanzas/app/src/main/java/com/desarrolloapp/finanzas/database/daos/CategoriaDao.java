package com.desarrolloapp.finanzas.database.daos;

public interface CategoriaDao {
}
